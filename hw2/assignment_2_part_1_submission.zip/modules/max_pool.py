import numpy as np

class MaxPooling:
    '''
    Max Pooling of input
    '''
    def __init__(self, kernel_size, stride):
        self.kernel_size = kernel_size
        self.stride = stride
        self.cache = None
        self.dx = None

    def forward(self, x):
        '''
        Forward pass of max pooling
        :param x: input, (N, C, H, W)
        :return: The output by max pooling with kernel_size and stride
        '''
        out = None
        #############################################################################
        # TODO: Implement the max pooling forward pass.                             #
        # Hint:                                                                     #
        #       1) You may implement the process with loops                         #
        #############################################################################
        N, C, H, W = x.shape
        k = self.kernel_size
        s = self.stride
        H_out = (H - k) // s + 1
        W_out = (W - k) // s + 1
        out = np.zeros((N, C, H_out, W_out))


        for n in range(N):
            for c in range(C):
                for h in range(H_out):
                    for w in range(W_out):
                        h_start = h * s
                        h_end = h_start + k
                        w_start = w * s
                        w_end = w_start + k

                        out[n, c, h, w] = np.max(x[n, c, h_start:h_end, w_start:w_end])        
        #############################################################################
        #                              END OF YOUR CODE                             #
        #############################################################################
        self.cache = (x, H_out, W_out)
        return out

    def backward(self, dout):
        '''
        Backward pass of max pooling
        :param dout: Upstream derivatives
        :return:
        '''
        x, H_out, W_out = self.cache
        #############################################################################
        # TODO: Implement the max pooling backward pass.                            #
        # Hint:                                                                     #
        #       1) You may implement the process with loops                     #
        #       2) You may find np.unravel_index useful                             #
        #############################################################################
        N, C, H, W = x.shape
        k = self.kernel_size
        s = self.stride
        dx = np.zeros_like(x)

        for n in range(N):
            for c in range(C):
                for h in range(H_out):
                    for w in range(W_out):
                        h_start = h * s
                        h_end = h_start + k
                        w_start = w * s
                        w_end = w_start + k

                        x_slice = x[n, c, h_start:h_end, w_start:w_end]
                        max_idx = np.unravel_index(np.argmax(x_slice), x_slice.shape)
                        
                        dx[n, c, h_start + max_idx[0], w_start + max_idx[1]] = dout[n, c, h, w]

        self.dx = dx       
        #############################################################################
        #                              END OF YOUR CODE                             #
        #############################################################################
